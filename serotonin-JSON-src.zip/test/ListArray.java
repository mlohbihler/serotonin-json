package test;

import java.util.List;

public class ListArray {
    private List<String[]> rows;

    public List<String[]> getRows() {
        return rows;
    }

    public void setRows(List<String[]> rows) {
        this.rows = rows;
    }
}
