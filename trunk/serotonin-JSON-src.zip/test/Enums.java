package test;

public enum Enums {
    FIRST, SECOND, THIRD, FOURTH;
}
